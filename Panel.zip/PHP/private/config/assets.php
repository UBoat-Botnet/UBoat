<?php

return [
    'css' => [
        'css/bootstrap.css',
        'css/style.css',
        'css/font-awesome.css',
        'js/jvectormap/jquery-jvectormap-1.2.2.css'
    ],
    'js' => [
        'js/jquery-1.12.0.min.js',
        'js/jvectormap/jquery-jvectormap-1.2.2.min.js',
        'js/jvectormap/jquery-jvectormap-world-mill-en.js',
        'js/chartjs/Chart.js',
        'js/bootstrap.js'
    ],
];