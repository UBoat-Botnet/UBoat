<?php
echo password_hash('password', PASSWORD_DEFAULT)
?>