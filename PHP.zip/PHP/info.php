<?php
// generate password hash from here
echo password_hash('testing', PASSWORD_DEFAULT);