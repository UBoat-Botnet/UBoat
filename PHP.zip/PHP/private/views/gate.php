<?php
/**
 * Created by PhpStorm.
 * User: Ben
 * Date: 1/29/2016
 * Time: 1:04 AM
 */
echo $data;