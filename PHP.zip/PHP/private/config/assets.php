<?php
/**
 * Created by PhpStorm.
 * User: Ben
 * Date: 1/19/2016
 * Time: 5:51 PM
 */
return [
    'css' => [
        'css/bootstrap.css',
        'css/style.css',
        'css/font-awesome.css',
        'js/jvectormap/jquery-jvectormap-1.2.2.css'
    ],
    'js' => [
        'js/jquery-1.12.0.min.js',
        'js/jvectormap/jquery-jvectormap-1.2.2.min.js',
        'js/jvectormap/jquery-jvectormap-world-mill-en.js',
        'js/chartjs/Chart.js',
        'js/bootstrap.js'
    ],
];